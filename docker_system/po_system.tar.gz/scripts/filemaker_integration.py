"""
FileMaker Data API Integration for PO Processing
Phase 1b - To be used after container testing is complete
"""

import requests
import json
import os
from datetime import datetime

class FileMakerIntegration:
    def __init__(self):
        self.server = os.getenv('FILEMAKER_SERVER', 'https://your-filemaker-server.com')
        self.database = os.getenv('FILEMAKER_DATABASE', 'PO_Database')
        self.username = os.getenv('FILEMAKER_USERNAME', 'api_user')
        self.password = os.getenv('FILEMAKER_PASSWORD', 'secure_password')
        self.token = None
        
    def authenticate(self):
        """Authenticate with FileMaker Data API"""
        url = f"{self.server}/fmi/data/v1/databases/{self.database}/sessions"
        
        auth_data = {
            "username": self.username,
            "password": self.password
        }
        
        headers = {
            'Content-Type': 'application/json'
        }
        
        try:
            response = requests.post(url, json=auth_data, headers=headers)
            if response.status_code == 200:
                self.token = response.json()['response']['token']
                print("✅ FileMaker authentication successful")
                return True
            else:
                print(f"❌ FileMaker authentication failed: {response.status_code}")
                return False
        except Exception as e:
            print(f"❌ FileMaker connection error: {e}")
            return False
    
    def insert_po_data(self, po_info):
        """Insert PO data into FileMaker database"""
        if not self.token:
            if not self.authenticate():
                return False
        
        # Map your JSON fields to FileMaker field names
        filemaker_data = {
            "fieldData": {
                "PO_Number": po_info.get("purchase_order_number"),
                "Production_Order": po_info.get("production_order"),
                "Part_Number": po_info.get("part_number"),
                "Revision": po_info.get("revision"),
                "Quantity": po_info.get("quantity"),
                "Dock_Date": po_info.get("dock_date"),
                "Vendor_Name": po_info.get("vendor_name"),
                "Buyer_Name": po_info.get("buyer_name"),
                "Payment_Terms": po_info.get("payment_terms"),
                "DPAS_Ratings": json.dumps(po_info.get("dpas_ratings", [])),
                "Quality_Clauses": json.dumps(po_info.get("quality_clauses", {})),
                "Processing_Date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "Source_File": po_info.get("source_file"),
                "Page_Count": po_info.get("page_count"),
                "Vendor_Non_Tek_Flag": po_info.get("vendor_non_tek_flag", False),
                "Payment_Terms_Non_Standard_Flag": po_info.get("payment_terms_non_standard_flag", False)
            }
        }
        
        url = f"{self.server}/fmi/data/v1/databases/{self.database}/layouts/PO_Layout/records"
        
        headers = {
            'Authorization': f'Bearer {self.token}',
            'Content-Type': 'application/json'
        }
        
        try:
            response = requests.post(url, json=filemaker_data, headers=headers)
            if response.status_code == 200:
                record_id = response.json()['response']['recordId']
                print(f"✅ PO {po_info.get('purchase_order_number')} inserted to FileMaker (Record ID: {record_id})")
                return True
            else:
                print(f"❌ FileMaker insert failed: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            print(f"❌ FileMaker insert error: {e}")
            return False
    
    def check_duplicate_po(self, po_number):
        """Check if PO already exists in FileMaker"""
        if not self.token:
            if not self.authenticate():
                return False
        
        url = f"{self.server}/fmi/data/v1/databases/{self.database}/layouts/PO_Layout/_find"
        
        find_request = {
            "query": [
                {"PO_Number": po_number}
            ]
        }
        
        headers = {
            'Authorization': f'Bearer {self.token}',
            'Content-Type': 'application/json'
        }
        
        try:
            response = requests.post(url, json=find_request, headers=headers)
            if response.status_code == 200:
                records = response.json().get('response', {}).get('data', [])
                return len(records) > 0
            else:
                return False
        except Exception as e:
            print(f"❌ FileMaker duplicate check error: {e}")
            return False
    
    def disconnect(self):
        """Logout from FileMaker Data API"""
        if self.token:
            url = f"{self.server}/fmi/data/v1/databases/{self.database}/sessions/{self.token}"
            try:
                requests.delete(url)
                print("✅ FileMaker session closed")
            except Exception as e:
                print(f"❌ FileMaker disconnect error: {e}")

# Example usage for integration into your pipeline
def integrate_with_filemaker(po_folder_path):
    """
    Integration function to be called after PO processing
    Add this to your process_po_complete.py
    """
    fm = FileMakerIntegration()
    
    # Read the processed JSON file
    json_file = os.path.join(po_folder_path, f"{os.path.basename(po_folder_path)}_info.json")
    
    if not os.path.exists(json_file):
        print(f"❌ JSON file not found: {json_file}")
        return False
    
    try:
        with open(json_file, 'r') as f:
            po_info = json.load(f)
        
        po_number = po_info.get("purchase_order_number")
        
        # Check for duplicates
        if fm.check_duplicate_po(po_number):
            print(f"⚠️  PO {po_number} already exists in FileMaker - skipping")
            return True
        
        # Insert new PO
        success = fm.insert_po_data(po_info)
        fm.disconnect()
        
        return success
        
    except Exception as e:
        print(f"❌ FileMaker integration error: {e}")
        return False

if __name__ == "__main__":
    # Test the connection
    fm = FileMakerIntegration()
    if fm.authenticate():
        print("FileMaker Data API connection test successful!")
        fm.disconnect()
    else:
        print("FileMaker Data API connection test failed!")