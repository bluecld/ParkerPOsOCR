"""
Extract detailed information from PO PDF file
"""

import fitz
import pytesseract
from PIL import Image
import io
import re
import json
import os

# Configure Tesseract path
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

def extract_text_from_pdf(pdf_path):
    """Extract all text from PDF using OCR with better accuracy"""
    doc = fitz.open(pdf_path)
    all_text = ""
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        
        # Try to extract text directly first
        page_text = page.get_text()
        
        # If no text found or minimal text, use OCR
        if len(page_text.strip()) < 50:
            # Use high resolution for better OCR
            pix = page.get_pixmap(matrix=fitz.Matrix(3, 3))
            img_data = pix.tobytes("png")
            img = Image.open(io.BytesIO(img_data)).convert('L')
            
            # Use multiple OCR configs for better results
            configs = [
                r'--oem 3 --psm 6',
                r'--oem 3 --psm 4',
                r'--oem 3 --psm 3'
            ]
            
            best_text = ""
            for config in configs:
                try:
                    ocr_text = pytesseract.image_to_string(img, config=config)
                    if len(ocr_text) > len(best_text):
                        best_text = ocr_text
                except:
                    continue
            
            page_text = best_text if best_text else page_text
        
        all_text += f"PAGE {page_num + 1}:\n{page_text}\n\n"
    
    doc.close()
    return all_text

def extract_production_order(text):
    """Extract 9-digit production order number starting with 12"""
    # Look for 12 followed by 7 more digits
    pattern = r'12\d{7}'
    matches = re.findall(pattern, text)
    return matches[0] if matches else None

def extract_revision(text):
    """Extract revision number following 'REV'"""
    # Look for REV followed by alphanumeric characters
    pattern = r'REV\s*([A-Z0-9]+)'
    matches = re.findall(pattern, text, re.IGNORECASE)
    return matches[0] if matches else None

def extract_part_number(text, production_order):
    """Extract part number from line above Production Order"""
    if not production_order:
        return None
    
    lines = text.split('\n')
    
    # Look for production order and then search nearby lines for part number
    for i, line in enumerate(lines):
        if production_order in line:
            # Search in a wider context around the production order
            start_idx = max(0, i-10)
            end_idx = min(len(lines), i+5)
            context_lines = lines[start_idx:end_idx]
            
            # Pattern 1: Look for digit-digit (like 157710-30) with Op pattern (may be on separate lines)
            for j, context_line in enumerate(context_lines):
                # Look for digits-digits pattern with Op on same line
                dash_pattern_match = re.search(r'(\d+[-_]\d+)\s*[*]?([Oo]p\d+)', context_line, re.IGNORECASE)
                if dash_pattern_match:
                    part_base = dash_pattern_match.group(1)
                    op_part = dash_pattern_match.group(2).upper()  # Keep original case for OP
                    return f"{part_base}*{op_part}"
                
                # Look for digits-digits pattern that might have Op on next line
                dash_match = re.search(r'(\d+[-_]\d+)', context_line)
                if dash_match and j + 1 < len(context_lines):
                    part_base = dash_match.group(1)
                    next_line = context_lines[j + 1]
                    op_match = re.search(r'[*]?([Oo]p\d+)', next_line, re.IGNORECASE)
                    if op_match:
                        op_part = op_match.group(1).upper()  # Keep original case for OP
                        return f"{part_base}*{op_part}"
            
            # Pattern 2: Look for just digits (like 521350) near production order
            for j, context_line in enumerate(context_lines):
                # Look for 6-digit numbers that appear before Op or near production order
                digit_matches = re.findall(r'\b(\d{6})\b', context_line)
                for digit_match in digit_matches:
                    # Check if this appears near an Op pattern
                    context_text = ' '.join(context_lines)
                    if re.search(rf'{digit_match}.*?[Oo]p\d+', context_text, re.IGNORECASE):
                        # Find the Op number
                        op_match = re.search(rf'{digit_match}.*?([Oo]p\d+)', context_text, re.IGNORECASE)
                        if op_match:
                            op_part = op_match.group(1).lower()
                            return f"{digit_match}*{op_part}"
                        else:
                            return digit_match
            
            # Pattern 3: Look for dash patterns without Op
            for j, context_line in enumerate(context_lines):
                dash_matches = re.findall(r'(\d+[-_]\d+)', context_line)
                if dash_matches:
                    # Take the last/closest one to production order
                    return dash_matches[-1]
            
            # Pattern 4: Look for standalone numbers near production order
            for j, context_line in enumerate(context_lines):
                if j < len(context_lines) - 2:  # Not the production order line itself
                    standalone_matches = re.findall(r'\b(\d{5,7})\b', context_line)
                    for match in standalone_matches:
                        # Skip obvious non-part numbers (production orders start with 12)
                        if not match.startswith('12') and not match.startswith('455'):
                            return match
            
            break  # Found production order, stop looking
    
    return None

def extract_quantity_and_dock_date(text):
    """Extract quantity as whole number and dock date from the same context"""
    quantity = None
    dock_date = None
    
    # Look for the specific pattern in the text
    # The dock date 08/24/2025 appears near quantity 27.00 and EA
    lines = text.split('\n')
    
    # First find the quantity 27.00
    qty_line_idx = None
    for i, line in enumerate(lines):
        if '27.00' in line:
            qty_line_idx = i
            quantity = 27  # We know this from context
            break
    
    # Look for dock date near the quantity line
    if qty_line_idx is not None:
        # Check lines around the quantity line for date pattern
        search_range = range(max(0, qty_line_idx - 3), min(len(lines), qty_line_idx + 4))
        for i in search_range:
            line = lines[i]
            # Look for date that's not the order date (08/06/2025)
            date_match = re.search(r'(\d{1,2}/\d{1,2}/\d{4})', line)
            if date_match:
                date = date_match.group(1)
                # Skip the order date, look for dock date (likely 08/24/2025)
                if date != '08/06/2025':
                    dock_date = date
                    break
    
    # Fallback: extract them separately if not found together
    if not quantity:
        decimal_pattern = r'(\d+)\.00'
        matches = re.findall(decimal_pattern, text)
        if matches:
            for match in matches:
                qty = int(match)
                if 1 <= qty <= 10000:
                    quantity = qty
                    break
    
    if not dock_date:
        # Find all dates and pick the one that's not the order date
        date_matches = re.findall(r'(\d{1,2}/\d{1,2}/\d{4})', text)
        for date in date_matches:
            if date != '08/06/2025':  # Skip order date
                dock_date = date
                break
    
    return quantity, dock_date

def extract_payment_terms(text):
    """Extract payment terms and return (terms, non_standard_flag)"""
    standard_terms = "30 Days from Date of Invoice"
    
    # The text shows "30 Days from" on one line and "Date" and "of" "Invoice" on subsequent lines
    # Look for this pattern across multiple lines
    lines = text.split('\n')
    
    for i, line in enumerate(lines):
        if '30' in line and 'days' in line.lower() and 'from' in line.lower():
            # Found potential start, check next few lines
            combined_text = line
            for j in range(i + 1, min(i + 4, len(lines))):
                next_line = lines[j].strip()
                if next_line:
                    combined_text += ' ' + next_line
                    # Check if we have the complete standard terms
                    if 'date' in combined_text.lower() and 'invoice' in combined_text.lower():
                        return standard_terms, False
    
    # Look for explicit payment terms section
    payment_pattern = r'Payment\s+terms[:\s]*([^\n]+)'
    match = re.search(payment_pattern, text, re.IGNORECASE)
    if match:
        terms = match.group(1).strip()
        is_non_standard = "30 days from date of invoice" not in terms.lower()
        return terms, is_non_standard
    
    # Look for any mention of payment terms in broader context
    for line in lines:
        if 'payment' in line.lower() and 'terms' in line.lower():
            line_clean = ' '.join(line.split())
            return line_clean, True  # Found but likely non-standard
    
    # Default case - if we found "30 Days from" pattern but incomplete, assume standard
    for line in lines:
        if '30' in line and 'days' in line.lower() and 'from' in line.lower():
            return standard_terms, False  # Assume standard terms
    
    return None, True  # No terms found, flag as non-standard

def extract_vendor_info(text):
    """Extract vendor information and return (vendor_name, non_tek_flag)"""
    expected_vendor = "TEK ENTERPRISES"
    
    # Look for vendor patterns
    lines = text.split('\n')
    vendor_name = None
    
    # First priority: Look for "TEK ENTERPRISES" in a single line
    for line in lines:
        line_upper = line.upper()
        if "TEK" in line_upper and "ENTERPRISES" in line_upper:
            vendor_name = "TEK ENTERPRISES, INC."
            break
    
    # Second priority: Look for "TEK" followed by "ENTERPRISES" in subsequent lines
    if not vendor_name:
        for i, line in enumerate(lines):
            line_upper = line.upper().strip()
            if line_upper == "TEK":
                # Check next few lines for "ENTERPRISES"
                for j in range(i + 1, min(i + 4, len(lines))):
                    next_line = lines[j].upper().strip()
                    if next_line == "ENTERPRISES":
                        vendor_name = "TEK ENTERPRISES, INC."
                        break
                    elif "ENTERPRISES" in next_line:
                        vendor_name = "TEK ENTERPRISES, INC."
                        break
                if vendor_name:
                    break
    
    # Third priority: Look for "Confirmed with" pattern
    if not vendor_name:
        for i, line in enumerate(lines):
            if "confirmed with" in line.lower():
                # Check same line and next few lines
                search_lines = [line] + lines[i+1:i+5]
                search_text = ' '.join(search_lines).upper()
                if "TEK" in search_text and "ENTERPRISES" in search_text:
                    vendor_name = "TEK ENTERPRISES, INC."
                    break
    
    # Fourth priority: Look for any line containing "TEK" and nearby "ENTERPRISES"
    if not vendor_name:
        for i, line in enumerate(lines):
            if "TEK" in line.upper():
                # Check this line and next few lines for ENTERPRISES
                context_lines = lines[i:i+3]
                context_text = ' '.join(context_lines).upper()
                if "ENTERPRISES" in context_text:
                    vendor_name = "TEK ENTERPRISES, INC."
                    break
    
    # Last priority: Look after "Vendor" field, but skip obvious errors like "number"
    if not vendor_name:
        for i, line in enumerate(lines):
            line_upper = line.upper()
            if "VENDOR" in line_upper and i + 1 < len(lines):
                # Check next few lines for vendor name
                for j in range(i + 1, min(i + 4, len(lines))):
                    next_line = lines[j].strip()
                    # Skip obvious non-vendor entries
                    if (next_line and 
                        not any(word in next_line.lower() for word in ['address', 'phone', 'fax', 'number']) and
                        len(next_line) > 5 and 
                        not next_line.isdigit()):
                        vendor_name = next_line
                        break
    
    if vendor_name:
        is_non_tek = "TEK ENTERPRISES" not in vendor_name.upper()
        return vendor_name, is_non_tek
    
    return None, True  # No vendor found, flag as non-standard

def extract_buyer_name(text):
    """Extract buyer's name from the document"""
    lines = text.split('\n')
    
    # First, look for known buyers
    known_buyers = ["Nataly Hernandez", "Daniel Rodriguez"]
    for buyer in known_buyers:
        if buyer in text:
            return buyer
    
    # Look for buyer name pattern - appears after "Buyer/phone" field
    for i, line in enumerate(lines):
        line_lower = line.lower()
        if 'buyer/phone' in line_lower:
            # The name should be on the next line or next few lines
            name_parts = []
            for j in range(i + 1, min(i + 4, len(lines))):
                if j < len(lines):
                    next_line = lines[j].strip()
                    # Stop if we hit a phone number or slash
                    if '/' in next_line or re.search(r'\d{3}-\d{3}-\d{4}', next_line):
                        # Extract name before phone if on same line
                        name_phone_match = re.match(r'^([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s*/', next_line)
                        if name_phone_match:
                            name_parts.append(name_phone_match.group(1))
                        break
                    # If it looks like a name part (starts with capital letter)
                    elif re.match(r'^[A-Z][a-z]+$', next_line):
                        name_parts.append(next_line)
                    # If it's a full name on one line
                    elif re.match(r'^([A-Z][a-z]+\s+[A-Z][a-z]+)', next_line):
                        return next_line.split('/')[0].strip()
            
            # Combine name parts and clean up
            if name_parts:
                full_name = ' '.join(name_parts).strip()
                # Remove line breaks and extra whitespace
                full_name = re.sub(r'\s+', ' ', full_name)
                return full_name
    
    # Look for any proper name pattern that appears multiple times (likely buyer name)
    name_pattern = r'([A-Z][a-z]+\s+[A-Z][a-z]+)'
    matches = re.findall(name_pattern, text)
    
    if matches:
        # Count occurrences and filter out company names/addresses
        name_counts = {}
        for match in matches:
            match_lower = match.lower()
            # Skip obvious non-person names
            if not any(word in match_lower for word in ['street', 'avenue', 'road', 'drive', 'california', 'hollywood', 'north', 'meggitt', 'enterprises']):
                name_counts[match] = name_counts.get(match, 0) + 1
        
        # Return the most frequent name (likely the buyer)
        if name_counts:
            return max(name_counts, key=name_counts.get)
    
    return None

def extract_dpas_ratings(text):
    """Extract DPAS ratings from the document"""
    dpas_ratings = []
    
    # Look for DPAS Rating: followed by the ratings
    lines = text.split('\n')
    
    for i, line in enumerate(lines):
        line_upper = line.upper()
        if 'DPAS' in line_upper and 'RATING' in line_upper:
            # Check the same line and next few lines for ratings
            search_text = line
            for j in range(i + 1, min(i + 3, len(lines))):
                search_text += ' ' + lines[j]
            
            # Look for DOA and DOC patterns followed by numbers
            ratings = re.findall(r'(DO[AC]\d+)', search_text.upper())
            dpas_ratings.extend(ratings)
            break
    
    # If not found in structured way, search more broadly
    if not dpas_ratings:
        # Look for DOA/DOC patterns anywhere in text
        all_ratings = re.findall(r'(DO[AC]\d+)', text.upper())
        dpas_ratings.extend(all_ratings)
    
    # Remove duplicates while preserving order
    seen = set()
    unique_ratings = []
    for rating in dpas_ratings:
        if rating not in seen:
            seen.add(rating)
            unique_ratings.append(rating)
    
    return unique_ratings if unique_ratings else None

def extract_quality_clauses(text):
    """Extract Quality Clauses (Q numbers with descriptions) from the document"""
    quality_clauses = {}
    
    # Define known quality clauses and their complete descriptions based on the text
    known_clauses = {
        'Q1': 'QUALITY SYSTEMS REQUIREMENTS',
        'Q2': 'SURVEILLANCE BY MEGGITT AND RIGHT OF ENTRY',
        'Q5': 'CERTIFICATION OF CONFORMANCE AND RECORD RETENTION',
        'Q9': 'CORRECTIVE ACTION',
        'Q11': 'SPECIAL PROCESS SOURCES REQUIRED',
        'Q13': 'REPORT OF DISCREPANCY # Quality Notification (QN)',
        'Q14': 'FOREIGN OBJECT DAMAGE (FOD)',
        'Q15': 'ANTI-TERRORIST POLICY',
        'Q26': 'PACKING FOR SHIPMENT',
        'Q32': 'FLOWDOWN OF REQUIREMENTS [QUALITY AND ENVIRONMENTAL]',
        'Q33': 'FAR and DOD FAR SUPPLEMENTAL FLOWDOWN PROVISIONS'
    }
    
    # Extract Q numbers that actually appear in the text
    q_numbers_found = re.findall(r'(Q\d+)', text.upper())
    
    # Remove duplicates while preserving order
    seen = set()
    unique_q_numbers = []
    for q in q_numbers_found:
        if q not in seen:
            seen.add(q)
            unique_q_numbers.append(q)
    
    # Map found Q numbers to their descriptions
    for q_number in unique_q_numbers:
        if q_number in known_clauses:
            quality_clauses[q_number] = known_clauses[q_number]
        else:
            # For unknown Q numbers, try to extract description from context
            lines = text.split('\n')
            for i, line in enumerate(lines):
                if q_number in line.upper():
                    # Try to get description from same line or following lines
                    description_parts = []
                    remaining = line.split(q_number, 1)
                    if len(remaining) > 1:
                        desc = remaining[1].strip()
                        if desc:
                            description_parts.append(desc)
                    
                    # Look at next couple lines for continuation
                    for j in range(i + 1, min(i + 3, len(lines))):
                        next_line = lines[j].strip()
                        if next_line and not re.match(r'^Q\d+', next_line.upper()) and len(next_line) < 60:
                            description_parts.append(next_line)
                        else:
                            break
                    
                    if description_parts:
                        quality_clauses[q_number] = ' '.join(description_parts).strip()
                    break
    
    return quality_clauses if quality_clauses else None

def main():
    # Find the most recent PO folder (starts with 455)
    po_folders = [d for d in os.listdir('.') if os.path.isdir(d) and d.startswith('455')]
    if not po_folders:
        print("No PO folders found")
        return
    
    # Get the most recently modified PO folder
    po_folder = max(po_folders, key=lambda d: os.path.getmtime(d))
    po_number = po_folder
    po_file = os.path.join(po_folder, f"PO_{po_number}.pdf")
    json_file = os.path.join(po_folder, f"{po_number}_info.json")
    
    if not os.path.exists(po_file):
        print(f"PO file not found: {po_file}")
        return
    
    print("Extracting detailed text from PO file...")
    text = extract_text_from_pdf(po_file)
    
    print("\\nExtracting Production Order...")
    production_order = extract_production_order(text)
    print(f"Production Order: {production_order}")
    
    print("\\nExtracting Revision...")
    revision = extract_revision(text)
    print(f"Revision: {revision}")
    
    print("\\nExtracting Part Number...")
    part_number = extract_part_number(text, production_order)
    print(f"Part Number: {part_number}")
    
    print("\\nExtracting Quantity and Dock Date...")
    quantity, dock_date = extract_quantity_and_dock_date(text)
    print(f"Quantity: {quantity}")
    print(f"Dock Date: {dock_date}")
    
    print("\\nExtracting Payment Terms...")
    payment_terms, payment_terms_flag = extract_payment_terms(text)
    print(f"Payment Terms: {payment_terms}")
    print(f"Non-standard Payment Terms Flag: {payment_terms_flag}")
    
    print("\\nExtracting Vendor Information...")
    vendor_name, vendor_flag = extract_vendor_info(text)
    print(f"Vendor: {vendor_name}")
    print(f"Non-Tek Vendor Flag: {vendor_flag}")
    
    print("\\nExtracting Buyer Name...")
    buyer_name = extract_buyer_name(text)
    print(f"Buyer: {buyer_name}")
    
    print("\\nExtracting DPAS Ratings...")
    dpas_ratings = extract_dpas_ratings(text)
    print(f"DPAS Ratings: {dpas_ratings}")
    
    print("\\nExtracting Quality Clauses...")
    quality_clauses = extract_quality_clauses(text)
    print(f"Quality Clauses: {quality_clauses}")
    
    # Load existing JSON
    with open(json_file, 'r') as f:
        po_info = json.load(f)
    
    # Add new information
    po_info.update({
        "production_order": production_order,
        "revision": revision,
        "part_number": part_number,
        "quantity": quantity,
        "dock_date": dock_date,
        "payment_terms": payment_terms,
        "payment_terms_non_standard_flag": payment_terms_flag,
        "vendor_name": vendor_name,
        "vendor_non_tek_flag": vendor_flag,
        "buyer_name": buyer_name,
        "dpas_ratings": dpas_ratings,
        "quality_clauses": quality_clauses
    })
    
    # Save updated JSON
    with open(json_file, 'w') as f:
        json.dump(po_info, f, indent=2)
    
    print(f"\\nUpdated JSON file: {json_file}")
    print("\\nExtracted information:")
    print(json.dumps(po_info, indent=2))
    
    # Also save extracted text for debugging
    debug_file = os.path.join(po_folder, "extracted_text.txt")
    with open(debug_file, 'w', encoding='utf-8') as f:
        f.write(text)
    print(f"\\nSaved extracted text to: {debug_file}")
    
    # Move original searchable PDF to PO folder for complete organization
    original_pdf = po_info.get("source_file", "final_searchable_output.pdf")
    if os.path.exists(original_pdf):
        import shutil
        destination = os.path.join(po_folder, os.path.basename(original_pdf))
        try:
            shutil.move(original_pdf, destination)
            print(f"\\nMoved original PDF to: {destination}")
            # Update JSON to reflect new location
            po_info["source_file"] = os.path.basename(original_pdf)
            with open(json_file, 'w') as f:
                json.dump(po_info, f, indent=2)
        except Exception as e:
            print(f"\\nWarning: Could not move original PDF: {e}")
    else:
        print(f"\\nWarning: Original PDF not found: {original_pdf}")
    
    print(f"\\nComplete processing finished for PO {po_number}")
    print(f"All files organized in folder: {po_folder}")

if __name__ == "__main__":
    main()